// TODO 1: Create 'Header' as a functional component to display the heading text. Write necessary import statement(s) too.
import React from 'react';

const Header = function() {
    return(
        <div>
           <h1> Password Strength Meter </h1>
        </div>
        )
}

export default Header;