// TODO 3: Create 'ProgressBar' as a functional component which is initially set at zero progress value. Write necessary import statement(s) too.
import React from 'react';

const ProgressBar = function() {
    const now=0;
    return(
        <div>
        <progress id="PBar" value={now} max="100"> Very Weak </progress>
        <label htmlFor='PBar'>Very Weak</label>
        </div>
        );
}

export default ProgressBar;