// TODO 2: Create 'Password' as a functional component to render the password input element. Write necessary import statement(s) too.
import React from 'react';

const Password = function() {
    return(
        <div>
          <form>
          <input type="password" id="password" placeholder="Type Your Password here"/>
          </form>
        </div>
        );
}

export default Password;
