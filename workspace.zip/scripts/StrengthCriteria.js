// TODO 4: Create 'StrengthCriteria' as a functional component to render the list of criteria for analyzing a strong password. Write necessary import statement(s) too.
import React from 'react';

const StrengthCriteria = function() {
    return(
        <div>
          <div>Minimum 8 characters long</div>
          <div>Atleast 1 special character</div>
          <div>Atleast 1 number</div>
          <div>Atleast 1 capital letter</div>
        </div>
        )
}

export default StrengthCriteria;